var classjogo_1_1_jewel =
[
    [ "Jewel", "classjogo_1_1_jewel.html#adc05b4beeefb405b06ade340ac40479b", null ],
    [ "Value", "classjogo_1_1_jewel.html#ab8132d9b0fc5e24a16c2da7a202d5ed7", null ]
];
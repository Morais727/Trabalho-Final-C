var _jewel_blue_8cs =
[
    [ "jogo.JewelBlue", "classjogo_1_1_jewel_blue.html", "classjogo_1_1_jewel_blue" ]
];
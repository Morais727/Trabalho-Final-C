var namespaces_dup =
[
    [ "jogo", "namespacejogo.html", "namespacejogo" ]
];
var interfacejogo_1_1_cell =
[
    [ "Display", "interfacejogo_1_1_cell.html#a2a527fa7b6920d2d2a7a308ffd5d612a", null ]
];
var dir_850d2419172caf406802ec76f4560b7b =
[
    [ ".NETCoreApp,Version=v7.0.AssemblyAttributes.cs", "mapa_2obj_2_debug_2net7_80_2_8_n_e_t_core_app_00_version_0av7_80_8_assembly_attributes_8cs.html", null ],
    [ "mapa.AssemblyInfo.cs", "mapa_8_assembly_info_8cs.html", null ],
    [ "mapa.GlobalUsings.g.cs", "mapa_8_global_usings_8g_8cs.html", null ]
];
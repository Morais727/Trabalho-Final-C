var classjogo_1_1_jewel_blue =
[
    [ "JewelBlue", "classjogo_1_1_jewel_blue.html#a06f2deea3935ea77c2666f81dd07374c", null ],
    [ "Display", "classjogo_1_1_jewel_blue.html#a77e8c0259ba28c17133387c88626d5fb", null ]
];
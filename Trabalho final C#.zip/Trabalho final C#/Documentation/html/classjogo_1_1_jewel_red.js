var classjogo_1_1_jewel_red =
[
    [ "JewelRed", "classjogo_1_1_jewel_red.html#aa1db129e78de605ed34a9f807ac80988", null ],
    [ "Display", "classjogo_1_1_jewel_red.html#a7cb0f9f1a8d806422c709c4d8ccb760f", null ]
];
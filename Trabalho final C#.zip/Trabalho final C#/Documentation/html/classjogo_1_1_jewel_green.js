var classjogo_1_1_jewel_green =
[
    [ "JewelGreen", "classjogo_1_1_jewel_green.html#a9716e02d305ef94b30c63cbad2afcf97", null ],
    [ "Display", "classjogo_1_1_jewel_green.html#a1e222fa46d1ab3e1ca3c7a13ed160db7", null ]
];
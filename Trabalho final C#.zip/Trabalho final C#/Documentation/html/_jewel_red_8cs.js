var _jewel_red_8cs =
[
    [ "jogo.JewelRed", "classjogo_1_1_jewel_red.html", "classjogo_1_1_jewel_red" ]
];
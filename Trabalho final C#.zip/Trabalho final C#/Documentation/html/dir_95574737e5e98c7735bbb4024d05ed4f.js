var dir_95574737e5e98c7735bbb4024d05ed4f =
[
    [ ".NETCoreApp,Version=v7.0.AssemblyAttributes.cs", "jog_2obj_2_debug_2net7_80_2_8_n_e_t_core_app_00_version_0av7_80_8_assembly_attributes_8cs.html", null ],
    [ "jogo.AssemblyInfo.cs", "jogo_8_assembly_info_8cs.html", null ],
    [ "jogo.GlobalUsings.g.cs", "jogo_8_global_usings_8g_8cs.html", null ]
];
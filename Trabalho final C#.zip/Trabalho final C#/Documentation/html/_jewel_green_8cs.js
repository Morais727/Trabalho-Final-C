var _jewel_green_8cs =
[
    [ "jogo.JewelGreen", "classjogo_1_1_jewel_green.html", "classjogo_1_1_jewel_green" ]
];
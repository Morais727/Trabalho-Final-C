var classjogo_1_1_energy =
[
    [ "Energy", "classjogo_1_1_energy.html#a9c1fc728c08429db0a3f061d3fdd0406", null ],
    [ "Value", "classjogo_1_1_energy.html#a27bd85db6781e1236a721b2b46ae1adb", null ]
];
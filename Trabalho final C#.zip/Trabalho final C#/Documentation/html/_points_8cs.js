var _points_8cs =
[
    [ "jogo.Points", "classjogo_1_1_points.html", "classjogo_1_1_points" ]
];
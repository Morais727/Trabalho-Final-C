var _level_8cs =
[
    [ "jogo.Position", "classjogo_1_1_position.html", "classjogo_1_1_position" ],
    [ "jogo.Level", "classjogo_1_1_level.html", "classjogo_1_1_level" ]
];
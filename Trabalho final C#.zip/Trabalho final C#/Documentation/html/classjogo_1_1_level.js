var classjogo_1_1_level =
[
    [ "Level", "classjogo_1_1_level.html#a5881ff68bc08712f39f6dd782b666f80", null ],
    [ "DisplayLevel", "classjogo_1_1_level.html#adbea032b274c32d395b9ad2e4b822458", null ],
    [ "GetJewelPositions", "classjogo_1_1_level.html#ae44c0d146484d9c5f76b7757c058bb70", null ],
    [ "GetMaxColumn", "classjogo_1_1_level.html#a7466ee28a61db52163a1b5f54f322c3b", null ],
    [ "GetMaxRow", "classjogo_1_1_level.html#add6de6c5d69a5b9fb18b10cc759a8e1c", null ],
    [ "GetTotalJewels", "classjogo_1_1_level.html#afef157b94633de43011da832b6f08a46", null ],
    [ "GetTreePositions", "classjogo_1_1_level.html#a02e5b73d66a62853ddcb33c9e2077802", null ],
    [ "GetWaterPositions", "classjogo_1_1_level.html#a728f22c4f3c5f96f90cadc8423f238ca", null ],
    [ "IsCellEmpty", "classjogo_1_1_level.html#aeb659deb6d144d5f4ed3db1f72b41564", null ],
    [ "IsOccupiedByOtherItems", "classjogo_1_1_level.html#a451cb070955be95d2c509af9f070ebe8", null ],
    [ "JewelPosition", "classjogo_1_1_level.html#af8d106d9508dc83ecca56a65a9b1279a", null ],
    [ "MapSize", "classjogo_1_1_level.html#a8c39ccd14141ac2758904804d4dec5f3", null ],
    [ "RadioactivePosition", "classjogo_1_1_level.html#afe83a913304f0c692c36808892204b49", null ],
    [ "ShuffleMap", "classjogo_1_1_level.html#a92b796a22eb45d6b26956c7fbd9130aa", null ],
    [ "ShufflePositions< T >", "classjogo_1_1_level.html#a295a54ec9030e12c0fd1e5811404909f", null ],
    [ "TreePosition", "classjogo_1_1_level.html#a4fc86864f2d50f37d16b8d48c7a41e24", null ],
    [ "UpdateLevel", "classjogo_1_1_level.html#a9710443b7b14167041fb4d2e02ec8d6a", null ],
    [ "WaterPosition", "classjogo_1_1_level.html#ae2b6162e6c4f6676981f3e3a20603f72", null ]
];
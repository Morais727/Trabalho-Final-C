var searchData=
[
  ['points_0',['Points',['../classjogo_1_1_points.html',1,'jogo']]],
  ['position_1',['Position',['../classjogo_1_1_position.html',1,'jogo']]]
];

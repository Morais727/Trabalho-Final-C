var searchData=
[
  ['updatelevel_0',['UpdateLevel',['../classjogo_1_1_level.html#a9710443b7b14167041fb4d2e02ec8d6a',1,'jogo::Level']]]
];

var searchData=
[
  ['jewel_0',['Jewel',['../classjogo_1_1_jewel.html#adc05b4beeefb405b06ade340ac40479b',1,'jogo.Jewel.Jewel()'],['../classjogo_1_1_jewel.html',1,'jogo.Jewel']]],
  ['jewel_2ecs_1',['Jewel.cs',['../_jewel_8cs.html',1,'']]],
  ['jewelblue_2',['JewelBlue',['../classjogo_1_1_jewel_blue.html#a06f2deea3935ea77c2666f81dd07374c',1,'jogo.JewelBlue.JewelBlue()'],['../classjogo_1_1_jewel_blue.html',1,'jogo.JewelBlue']]],
  ['jewelblue_2ecs_3',['JewelBlue.cs',['../_jewel_blue_8cs.html',1,'']]],
  ['jewelcolector_2ecs_4',['JewelColector.cs',['../_jewel_colector_8cs.html',1,'']]],
  ['jewelcollector_5',['JewelCollector',['../class_jewel_collector.html',1,'JewelCollector'],['../classjogo_1_1_jewel_collector.html',1,'jogo.JewelCollector']]],
  ['jewelgreen_6',['JewelGreen',['../classjogo_1_1_jewel_green.html#a9716e02d305ef94b30c63cbad2afcf97',1,'jogo.JewelGreen.JewelGreen()'],['../classjogo_1_1_jewel_green.html',1,'jogo.JewelGreen']]],
  ['jewelgreen_2ecs_7',['JewelGreen.cs',['../_jewel_green_8cs.html',1,'']]],
  ['jewelposition_8',['JewelPosition',['../classjogo_1_1_level.html#af8d106d9508dc83ecca56a65a9b1279a',1,'jogo::Level']]],
  ['jewelred_9',['JewelRed',['../classjogo_1_1_jewel_red.html#aa1db129e78de605ed34a9f807ac80988',1,'jogo.JewelRed.JewelRed()'],['../classjogo_1_1_jewel_red.html',1,'jogo.JewelRed']]],
  ['jewelred_2ecs_10',['JewelRed.cs',['../_jewel_red_8cs.html',1,'']]],
  ['jogo_11',['jogo',['../namespacejogo.html',1,'']]],
  ['jogo_12',['Jogo',['../md__j_o_g_o1_2_r_e_a_d_m_e.html',1,'']]],
  ['jogo_2eassemblyinfo_2ecs_13',['jogo.AssemblyInfo.cs',['../jogo_8_assembly_info_8cs.html',1,'']]],
  ['jogo_2eglobalusings_2eg_2ecs_14',['jogo.GlobalUsings.g.cs',['../jogo_8_global_usings_8g_8cs.html',1,'']]]
];

var searchData=
[
  ['great_0',['great',['../classjogo_1_1_robot.html#ac6a65a24934b945703e7d15d3fe0c4e3',1,'jogo::Robot']]]
];

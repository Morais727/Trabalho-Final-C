var searchData=
[
  ['waterposition_0',['WaterPosition',['../classjogo_1_1_level.html#ae2b6162e6c4f6676981f3e3a20603f72',1,'jogo::Level']]]
];

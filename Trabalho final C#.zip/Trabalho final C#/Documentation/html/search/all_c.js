var searchData=
[
  ['playgame_0',['PlayGame',['../classjogo_1_1_jewel_collector.html#ae25ce6f1761034c9bfff198cdc275437',1,'jogo::JewelCollector']]],
  ['points_1',['Points',['../classjogo_1_1_points.html',1,'jogo.Points'],['../classjogo_1_1_points.html#a9effa286c82035fe0217e4c063ffe231',1,'jogo.Points.Points()']]],
  ['points_2ecs_2',['Points.cs',['../_points_8cs.html',1,'']]],
  ['position_3',['Position',['../classjogo_1_1_position.html',1,'jogo']]],
  ['program_2ecs_4',['Program.cs',['../mapa_2_program_8cs.html',1,'(Global Namespace)'],['../robo_2_program_8cs.html',1,'(Global Namespace)']]]
];

var searchData=
[
  ['_2enetcoreapp_2cversion_3dv7_2e0_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v7.0.AssemblyAttributes.cs',['../jog_2obj_2_debug_2net7_80_2_8_n_e_t_core_app_00_version_0av7_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../mapa_2obj_2_debug_2net7_80_2_8_n_e_t_core_app_00_version_0av7_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../robo_2obj_2_debug_2net7_80_2_8_n_e_t_core_app_00_version_0av7_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)']]]
];

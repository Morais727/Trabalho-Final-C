var searchData=
[
  ['radioactive_0',['Radioactive',['../classjogo_1_1_radioactive.html#abc2a340f59b6880e17b2629c6cecc5ab',1,'jogo::Radioactive']]],
  ['radioactiveposition_1',['RadioactivePosition',['../classjogo_1_1_level.html#afe83a913304f0c692c36808892204b49',1,'jogo::Level']]],
  ['really_2',['really',['../classjogo_1_1_robot.html#a46132c5acb72f3c9089e64620e90d6b2',1,'jogo::Robot']]],
  ['robot_3',['Robot',['../classjogo_1_1_robot.html#aa218bc9e69a28d8c3907b935ccbb63e1',1,'jogo::Robot']]]
];

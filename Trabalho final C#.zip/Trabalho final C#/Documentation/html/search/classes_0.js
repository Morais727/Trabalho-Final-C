var searchData=
[
  ['cell_0',['Cell',['../interfacejogo_1_1_cell.html',1,'jogo']]],
  ['charger_1',['Charger',['../classjogo_1_1_charger.html',1,'jogo']]]
];

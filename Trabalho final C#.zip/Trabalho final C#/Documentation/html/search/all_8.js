var searchData=
[
  ['invalidkey_0',['InvalidKey',['../classjogo_1_1_robot.html#a357595b66cc4fe858ff113264cea17ac',1,'jogo::Robot']]],
  ['iscellempty_1',['IsCellEmpty',['../classjogo_1_1_level.html#aeb659deb6d144d5f4ed3db1f72b41564',1,'jogo::Level']]],
  ['isoccupiedbyotheritems_2',['IsOccupiedByOtherItems',['../classjogo_1_1_level.html#a451cb070955be95d2c509af9f070ebe8',1,'jogo::Level']]]
];

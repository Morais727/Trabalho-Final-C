var searchData=
[
  ['column_0',['Column',['../classjogo_1_1_position.html#a9c2ad3560be06adbdc5f44ea7997a2ba',1,'jogo::Position']]],
  ['columns_1',['Columns',['../classjogo_1_1_map.html#acd7a97863420434459467ef1024a1e5e',1,'jogo::Map']]]
];

var searchData=
[
  ['empty_0',['Empty',['../classjogo_1_1_empty.html',1,'jogo']]],
  ['energy_1',['Energy',['../classjogo_1_1_energy.html',1,'jogo']]]
];

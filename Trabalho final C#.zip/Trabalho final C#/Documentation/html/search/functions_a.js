var searchData=
[
  ['playgame_0',['PlayGame',['../classjogo_1_1_jewel_collector.html#ae25ce6f1761034c9bfff198cdc275437',1,'jogo::JewelCollector']]],
  ['points_1',['Points',['../classjogo_1_1_points.html#a9effa286c82035fe0217e4c063ffe231',1,'jogo::Points']]]
];

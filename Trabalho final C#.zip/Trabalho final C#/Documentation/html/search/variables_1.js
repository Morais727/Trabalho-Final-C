var searchData=
[
  ['currentcolumn_0',['currentColumn',['../classjogo_1_1_robot.html#ae955068952d08290ec5d9fe93a611f8c',1,'jogo::Robot']]],
  ['currentenergy_1',['currentEnergy',['../classjogo_1_1_robot.html#a304e8714c70c023f3d8eedffc091b311',1,'jogo::Robot']]],
  ['currentlevel_2',['currentLevel',['../classjogo_1_1_robot.html#a0eb6596ac2cbd1a662aaec0db9ed2920',1,'jogo::Robot']]],
  ['currentpoints_3',['currentPoints',['../classjogo_1_1_robot.html#a61bed0823718bfcf884607f6f2a9da0d',1,'jogo::Robot']]],
  ['currentrow_4',['currentRow',['../classjogo_1_1_robot.html#a221e968bc13ab4f6d9fd4a54f51672c4',1,'jogo::Robot']]]
];

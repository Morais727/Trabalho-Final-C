var searchData=
[
  ['level_0',['Level',['../classjogo_1_1_level.html#a5881ff68bc08712f39f6dd782b666f80',1,'jogo::Level']]]
];

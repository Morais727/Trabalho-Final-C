var searchData=
[
  ['energyamount_0',['EnergyAmount',['../classjogo_1_1_robot.html#a3efa405dff1a3ac5fe05eee6ac14fc6c',1,'jogo::Robot']]],
  ['error_1',['error',['../classjogo_1_1_robot.html#a8c97ff90c6c6afccd2977756dd5ba6d4',1,'jogo::Robot']]]
];

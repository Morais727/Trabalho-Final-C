var searchData=
[
  ['row_0',['Row',['../classjogo_1_1_position.html#a3d140fe6a4ca0dea43be4b6553fe0fab',1,'jogo::Position']]],
  ['rows_1',['Rows',['../classjogo_1_1_map.html#a1db60147b809e7349a067d96d8e8ebd8',1,'jogo::Map']]]
];

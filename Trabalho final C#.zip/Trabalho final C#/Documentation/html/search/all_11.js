var searchData=
[
  ['value_0',['Value',['../classjogo_1_1_energy.html#a27bd85db6781e1236a721b2b46ae1adb',1,'jogo.Energy.Value'],['../classjogo_1_1_jewel.html#ab8132d9b0fc5e24a16c2da7a202d5ed7',1,'jogo.Jewel.Value']]]
];

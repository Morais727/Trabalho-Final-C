var classjogo_1_1_charger =
[
    [ "Charger", "classjogo_1_1_charger.html#ae1e511523fa9144a364739229dad00d6", null ],
    [ "DetermineColor", "classjogo_1_1_charger.html#a58e583a6ca05fbffd0ebe979134a28d0", null ],
    [ "DisplayEnergy", "classjogo_1_1_charger.html#a8c6f7f4ec3853f9a66c1dafd0275a6c8", null ]
];
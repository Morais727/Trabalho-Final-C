var classjogo_1_1_points =
[
    [ "Points", "classjogo_1_1_points.html#a9effa286c82035fe0217e4c063ffe231", null ],
    [ "DisplayPoints", "classjogo_1_1_points.html#a74fa26c9efaf1385d465e424dc2b73b8", null ]
];